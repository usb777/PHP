<div id="header" align="center" class="red"> Admin-side </div>
<div id="left">
  <b class="green">Menu</b>
  <p class="left_menu"><a href='backend.php'>Show all books</a></p>
  <p class="left_menu"><a href='bookUploader.php'>Upload new book</a></p>
  <p class="left_menu"><a href='backendUpdateUser.php'>Update User profile</a></p>
  <p class="left_menu"><a href='logout.php'>Sign out</a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>