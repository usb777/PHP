<?php
//Mysql connection login and password, Database name

        define('DB_NAME', 'db_library');
        define('DB_USER', 'root');
        define('DB_PASSWORD', '');
        define('DB_HOST', 'localhost');		
		define('GLOBAL_ROOT', $_SERVER['DOCUMENT_ROOT']);
		


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_library";

$GLOBAL_SITENAME = "Natali library";

$GLOBAL_HOST = 'http://'.$_SERVER['HTTP_HOST'].'';

//$GLOBAL_ROOT = $_SERVER['DOCUMENT_ROOT']; // system_way


/* Natalia style


$GLOBAL_HOST = 'http://'.$_SERVER['HTTP_HOST'].'/friendlibrary.comt'; 

 */
?>