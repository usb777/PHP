<div id="header" align="center"> Admin-side </div>
<div id="left">
  <b class="green">Menu</b>
  <p class="left_menu"><a href='backendSuperAdmin.php'>Show all users books</a></p>
  <p class="left_menu"><a href='backendSuperAdminAllUsers.php'>Show all users</a></p>
  <p class="left_menu"><a href='backendSuperAdminAllCategories.php'>Show all categories</a></p>
  <p class="left_menu"><a href='#'>Statistics</a></p>
  <p class="left_menu"><a href='logout.php'>Sign out</a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>