﻿<html>
    <body>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <p>
                <label for="file">Choose import.xml</label><br/>
                <input type="file" name="import" id="import" /></p>
            <p><input type="submit" name="submit" value="Submit" /></p>
        </form>
    <body>
</html>